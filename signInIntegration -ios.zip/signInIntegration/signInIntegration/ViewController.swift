//
//  ViewController.swift
//  signInIntegration
//
//  Created by Anilkumar on 09/06/22.
//

import UIKit
import GoogleSignIn
import FBSDKLoginKit
import AuthenticationServices

class ViewController: UIViewController {
    

    override func viewDidLoad() {
        super.viewDidLoad()
        let loginButton = FBLoginButton()
        let appleButton = ASAuthorizationAppleIDButton()
        appleButton.frame = CGRect(x: 20, y: 332, width: 388, height: 50)
        view.addSubview(appleButton)
        appleButton.addTarget(self, action: #selector(actionHandleAppleSignin), for: .touchUpInside)
        loginButton.center = view.center
        view.addSubview(loginButton)
        loginButton.frame = CGRect(x: 20, y: 492, width: 388, height: 50)
        let googleButton = GIDSignInButton()
        googleButton.center = view.center
        googleButton.frame = CGRect(x: 20, y: 432, width: 388, height: 50)
        view.addSubview(googleButton)
        GIDSignIn.sharedInstance()?.delegate = self
        GIDSignIn.sharedInstance()?.presentingViewController = self
        // Do any additional setup after loading the view.
    }
    @objc func actionHandleAppleSignin() {

            let appleIDProvider = ASAuthorizationAppleIDProvider()

            let request = appleIDProvider.createRequest()

            request.requestedScopes = [.fullName, .email]

            let authorizationController = ASAuthorizationController(authorizationRequests: [request])

            authorizationController.delegate = self

            authorizationController.presentationContextProvider = self

            authorizationController.performRequests()

        }
    func showAlert(title : String, message : String){
            let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
                   let alertAction = UIAlertAction(title: "OK", style: .default) { (action) in
                       alert.dismiss(animated: true, completion: nil)
                   }
                   alert.addAction(alertAction)
                   self.present(alert, animated: false, completion: nil)
        }


}
extension ViewController : GIDSignInDelegate{
    func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!, withError error: Error!) {
        if let error = error {
                    if (error as NSError).code == GIDSignInErrorCode.hasNoAuthInKeychain.rawValue {
                        debugPrint("The user has not signed in before or they have since signed out.")
                    } else {
                        debugPrint("\(error.localizedDescription)")
                    }
                    return
                }
                debugPrint(user.profile.email ?? "")
                debugPrint(user.profile.name ?? "")
                debugPrint(user.profile.givenName ?? "")
                debugPrint(user.profile.familyName ?? "")
                showAlert(title: "SUCCESS", message: "Thanks for signing in with google")
          
    }
      
    func sign(_ signIn: GIDSignIn!, didDisconnectWith user: GIDGoogleUser!,
              withError error: Error!) {
        // Perform any operations when the user disconnects from the app here.
        // ...
    }
      
    func sign(_ signIn: GIDSignIn!, present viewController: UIViewController!) {
        self.present(viewController, animated: true, completion: nil)
          
    }
      
    func sign(_ signIn: GIDSignIn!, dismiss viewController: UIViewController!) {
        self.dismiss(animated: true, completion: nil)
    }
}

extension ViewController: ASAuthorizationControllerDelegate {

     // ASAuthorizationControllerDelegate function for authorization failed

    func authorizationController(controller: ASAuthorizationController, didCompleteWithError error: Error) {

        print(error.localizedDescription)

    }

       // ASAuthorizationControllerDelegate function for successful authorization

    func authorizationController(controller: ASAuthorizationController, didCompleteWithAuthorization authorization: ASAuthorization) {

        if let appleIDCredential = authorization.credential as? ASAuthorizationAppleIDCredential {

            // Create an account as per your requirement

            let appleId = appleIDCredential.user

            let appleUserFirstName = appleIDCredential.fullName?.givenName

            let appleUserLastName = appleIDCredential.fullName?.familyName

            let appleUserEmail = appleIDCredential.email

            //Write your code

        } else if let passwordCredential = authorization.credential as? ASPasswordCredential {

            let appleUsername = passwordCredential.user

            let applePassword = passwordCredential.password

            //Write your code

        }

    }

}

extension ViewController: ASAuthorizationControllerPresentationContextProviding {

    //For present window

    func presentationAnchor(for controller: ASAuthorizationController) -> ASPresentationAnchor {

        return self.view.window!

    }

}
